﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StressdetectionViaFace.Segmentation
{
    class SegmentationImage
    {
        // we need a gradient image
        // we need a greyscaled image 
        // we need a color image 
        // we need a graph

    }
}
